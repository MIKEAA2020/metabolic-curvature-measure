# Main manuscript — Journal of Theoretical Biology (Elsevier)
# Compile-ready standalone package

Title: A Geometric Theory of Metabolic Flux Rerouting: How Active-Set
Curvature Predicts Transcriptional Regulation and Protein-Layer
Buffering

## How to compile
- Overleaf: upload this ZIP via New Project -> Upload Project, set the main
  document to journal_manuscript_v18.tex, recompile. (Run twice so natbib
  citations resolve; Overleaf does this automatically.)
- Command line: pdflatex journal_manuscript_v18.tex  (x2)

## Contents
- journal_manuscript_v18.tex        main source (main document)
- journal_manuscript_v18_refs.tex   reference list (input by the main file)
- journal_manuscript_v18_refs.bib   underlying BibTeX database (not required
  for compilation; included for editorial source completeness)
- m1_m3/, alexandrov_bridge/, association_robustness/  figure PNGs at the
  exact relative paths used by \includegraphics

## Journal of Theoretical Biology submission notes (Guide for Authors,
## verified live 2026-09-21)
- Article type: Regular Article.
- Abstract: 249 words (JTB cap: "does not exceed 250 words"), in two
  paragraphs (theory; biology).
- Keywords: 7 (JTB range 1-7), ending with 'path dependence'.
- Highlights: required by JTB as a separate editable file with
  'highlights' in the file name; provided in the repository at
  download/highlights_jtb.docx (5 bullets, each <= 85 characters incl.
  spaces, featuring the biological applications and the theoretical
  advancement). Upload it as its own file in the submission system.
- CRediT authorship contribution statement: included in the manuscript
  backmatter (required by JTB; single author, roles listed).
- Declaration of competing interests, funding sources, declaration of
  generative AI use, and the research-data statement: all included in
  the manuscript backmatter; the cover letter
  (download/cover_letter_jtb.md in the repository) carries the full
  disclosures.
- Author identity, affiliation, corresponding e-mail, and ORCID appear on
  the title page (\thanks footnote); e-mail and ORCID are clickable.
- Continuous line numbering is enabled via the lineno package.
- Reference style: author-year (natbib); Elsevier accepts any consistent
  style at first submission ("Your Paper Your Way").
