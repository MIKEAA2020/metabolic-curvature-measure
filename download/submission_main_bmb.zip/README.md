# Main manuscript — Bulletin of Mathematical Biology (Springer)
# Compile-ready standalone package

Title: A discrete curvature measure for flux balance analysis predicts
transcriptional regulation and translational buffering in Escherichia
coli

## How to compile
- Overleaf: upload this ZIP via New Project -> Upload Project, set the main
  document to journal_manuscript_v19.tex, recompile. (Run twice so natbib
  citations resolve; Overleaf does this automatically.)
- Command line: pdflatex journal_manuscript_v19.tex  (x2)

## Contents
- journal_manuscript_v19.tex          main source (main document)
- journal_manuscript_v19_bmb_refs.tex reference list (input by the main file)
- journal_manuscript_v19_refs.bib     underlying BibTeX database (not required
  for compilation; included for editorial source completeness)
- m1_m3/, alexandrov_bridge/, association_robustness/  figure PNGs at the
  exact relative paths used by \includegraphics

## Bulletin of Mathematical Biology submission notes (instructions to
## authors, live-verified earlier in the project)
- Article type: Original Research.
- Abstract: 243 words (Springer/BMB guideline: 150-250), a single
  narrative arc from the biological question to the findings.
- Keywords: 6 (BMB range 4-6): flux balance analysis; metabolic
  rerouting; active-set curvature; transcriptional regulation;
  translational buffering; epistasis.
- Author-contribution statement: included in the backmatter (CRediT
  taxonomy; single author, roles listed).
- Declaration of competing interests, funding sources, declaration of
  generative AI use, and the research-data statement: all included in
  the manuscript backmatter; the cover letter
  (download/cover_letter_bmb.md in the repository) carries the full
  disclosures.
- Author identity, affiliation, corresponding e-mail, and ORCID appear on
  the title page (\thanks footnote); e-mail and ORCID are clickable.
- Continuous line numbering is enabled via the lineno package.
- Reference style: author-year (natbib), alphabetical; Springer accepts
  any consistent style at first submission.
